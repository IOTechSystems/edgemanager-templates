import math

COUNTER = 0

def sawtooth (current_value, increment, max_value):
    new_value = current_value + increment
    if (new_value >= max_value):
        new_value = 0
    return new_value

def step_sawtooth (current_value, increment, max_value):
    # To create the step effect, only increment the value when COUNTER is odd
    if (COUNTER % 2 ==  0): 
        return current_value
    return sawtooth(current_value, increment, max_value)

def sinwave (amplitude, offset, period):
    return int(math.sin(2 * math.pi * (1/period) * COUNTER) * amplitude) + offset 

def coswave (amplitude, offset, period):
    return int(math.cos(2 * math.pi * (1/period) * COUNTER) * amplitude) + offset

def set_initial(resources):
    resources.get('Temperature').set_value(0)
    resources.get('Pressure').set_value(45)
    resources.get('Level').set_value(0)
    resources.get('Maximum').set_value(75)

def update_values(resources):
    global COUNTER
    COUNTER += 1
    
    temp = resources['Temperature']
    temp.set_value(sinwave(40, 50, 50))

    pressure = resources['Pressure']
    pressure.set_value(step_sawtooth(pressure.get_value(), 4, 100))

    level = resources['Level']
    level.set_value(coswave(10, 20, 50))
